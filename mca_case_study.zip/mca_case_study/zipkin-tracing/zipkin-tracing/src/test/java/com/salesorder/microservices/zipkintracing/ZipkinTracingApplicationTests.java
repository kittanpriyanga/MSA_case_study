package com.salesorder.microservices.zipkintracing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZipkinTracingApplicationTests {

	@Test
	void contextLoads() {
	}

}
