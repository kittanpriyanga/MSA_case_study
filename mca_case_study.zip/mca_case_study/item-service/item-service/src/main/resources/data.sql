Insert into Item(id,name,description,price) values (100L,'Book','C Programming',100);
Insert into Item(id,name,description,price) values (101L,'Pen','Parker Pen',10);
Insert into Item(id,name,description,price) values (102L,'Mobile','Redmi note 4',1500);
Insert into Item(id,name,description,price) values (103L,'Laptop','Del Laptop',100);
Insert into Item(id,name,description,price) values (104L,'Bag','American tourists',100); 