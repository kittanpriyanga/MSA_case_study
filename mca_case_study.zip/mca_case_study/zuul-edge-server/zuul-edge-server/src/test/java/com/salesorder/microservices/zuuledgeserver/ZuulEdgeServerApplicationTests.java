package com.salesorder.microservices.zuuledgeserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZuulEdgeServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
