insert into customer(email,first_name,last_name,port) values ('priya@cts.com','Priyanga','Kittan',0); 
insert into customer(email,first_name,last_name,port) values ('kittan@cognizant.com','Priyanga','Pri',0); 
insert into customer(email,first_name,last_name,port) values ('test.one@mail.com','Test','One',0);
insert into customer(email,first_name,last_name,port) values ('karthi.test@gmail.com','Test','Data',0); 