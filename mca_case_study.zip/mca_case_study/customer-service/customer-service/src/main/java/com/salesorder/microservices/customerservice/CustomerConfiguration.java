package com.salesorder.microservices.customerservice;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@ConfigurationProperties(prefix="customer_service")
@Component
public class CustomerConfiguration {
private String defautFirstName;
private String defautLastName;
private String defaultEmail;
public String getDefautFirstName() {
	return defautFirstName;
}
public void setDefautFirstName(String defautFirstName) {
	this.defautFirstName = defautFirstName;
}
public String getDefautLastName() {
	return defautLastName;
}
public void setDefautLastName(String defautLastName) {
	this.defautLastName = defautLastName;
}
public String getDefaultEmail() {
	return defaultEmail;
}
public void setDefaultEmail(String defaultEmail) {
	this.defaultEmail = defaultEmail;
}


}
