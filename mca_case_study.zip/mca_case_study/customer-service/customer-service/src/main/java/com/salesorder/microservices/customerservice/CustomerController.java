package com.salesorder.microservices.customerservice;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.netflix.hystrix.EnableHystrix;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@RestController
@EnableHystrix
public class CustomerController {
	private static final Logger logger = LoggerFactory.getLogger(CustomerController.class);
	@Autowired
	CustomerRepository customerRepository;
	
	@Autowired
	Environment environment;
	@Autowired
	CustomerConfiguration customerConfiguration;
	@GetMapping("/api/service1/customers")
	public List<Customer> getCustomers() {
		//return new Customer("priyanga.kittan@cts.com","Priyanga","Kittan");
		List<Customer> customer =customerRepository.findAll();
		return customer;
	}
	@GetMapping("/api/service1/customers/email/{emailId:.+}")
	public Customer getCustomerDetails(@PathVariable("emailId") String emailId) {
		logger.info("Inside getCustomerDetails");
		Optional<Customer> customer =customerRepository.findByEmail(emailId);
		customer.get().setPort(Integer.parseInt(environment.getProperty("local.server.port")));
		return customer.get();

	}
	@GetMapping("/api/service1/customers/email/fault-tolerance")
	@HystrixCommand(fallbackMethod="fallBackCustomerDetails")
	public Customer getCustomerDetailsFaultTolerance() {
		throw new RuntimeException("Some issue");
	}
	public Customer fallBackCustomerDetails() {
		return new Customer (customerConfiguration.getDefaultEmail(),customerConfiguration.getDefautFirstName(),customerConfiguration.getDefautLastName(),0);
	}

}
