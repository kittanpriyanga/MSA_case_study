package com.salesorder.microservices.orderservice;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

//@FeignClient(name="item-service",url="localhost:8001")
//@FeignClient(name="item-service")
@FeignClient(name="zuul-edge-server")
  
@RibbonClient(name="item-service")
public interface ItemService {

	@GetMapping("/item-service/items/{itemname}")
	public OrderLineItem getItemDetails(@PathVariable("itemname") String itemname);
	
}
