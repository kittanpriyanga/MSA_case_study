package com.salesorder.microservices.orderservice;

import java.util.List;
import java.util.Optional;

public class SalesOrderDto {
private String orderDescription;
private String orderDate;
private String emailId;
private List<ItemList> itemList;
private Integer price;
private Optional<SalesOrder> salesOrder;
private List<OrderLineItem> orderLineItem;

public String getOrderDescription() {
	return orderDescription;
}
public void setOrderDescription(String orderDescription) {
	this.orderDescription = orderDescription;
}
public String getOrderDate() {
	return orderDate;
}
public void setOrderDate(String orderDate) {
	this.orderDate = orderDate;
}
public String getEmailId() {
	return emailId;
}
public void setEmailId(String emailId) {
	this.emailId = emailId;
}

public Integer getPrice() {
	return price;
}
public void setPrice(Integer price) {
	this.price = price;
}
public List<ItemList> getItemList() {
	return itemList;
}
public void setItemList(List<ItemList> itemList) {
	this.itemList = itemList;
}
public Optional<SalesOrder> getSalesOrder() {
	return salesOrder;
}
public void setSalesOrder(Optional<SalesOrder> salesOrder2) {
	this.salesOrder = salesOrder2;
}
public List<OrderLineItem> getOrderLineItem() {
	return orderLineItem;
}
public void setOrderLineItem(List<OrderLineItem> orderLineItem) {
	this.orderLineItem = orderLineItem;
}


}
