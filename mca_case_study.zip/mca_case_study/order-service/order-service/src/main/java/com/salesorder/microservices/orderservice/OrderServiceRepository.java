package com.salesorder.microservices.orderservice;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

public interface OrderServiceRepository extends JpaRepository<SalesOrder, Long> {

	Optional<SalesOrder> findByEmail(String emailId);

	
}
