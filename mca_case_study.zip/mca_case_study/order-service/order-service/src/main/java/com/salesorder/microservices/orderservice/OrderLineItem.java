package com.salesorder.microservices.orderservice;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="order_line_item")
public class OrderLineItem {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	@Column(name="id")
	private Long id;

	@Column(name="item_name")
	private String name;

	@Column(name="quantity")
	private Integer quantity;

	@Column(name="order_id")
	private Long orderId;
	
	private Integer price;

	public OrderLineItem(Long id, String name, Integer quantity, Long orderId) {
		super();
		this.id = id;
		this.name = name;
		this.quantity = quantity;
		this.orderId = orderId;
	}
	public OrderLineItem() {}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	public Long getOrderId() {
		return orderId;
	}
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}
	public Integer getPrice() {
		return price;
	}
	public void setPrice(Integer price) {
		this.price = price;
	}
	
}
