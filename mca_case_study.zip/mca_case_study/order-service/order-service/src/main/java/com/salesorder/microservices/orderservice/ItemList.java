package com.salesorder.microservices.orderservice;

public class ItemList {
private String itemName;
public String getItemName() {
	return itemName;
}
public void setItemName(String itemName) {
	this.itemName = itemName;
}
public Integer getQuantity() {
	return quantity;
}
public void setQuantity(Integer quantity) {
	this.quantity = quantity;
}
private Integer quantity;

}
