package com.salesorder.microservices.orderservice;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;


//@FeignClient(name="customer-service",url="localhost:8000")
//@FeignClient(name="customer-service")
@FeignClient(name="zuul-edge-server")

@RibbonClient(name="customer-service")

public interface CustomerService {
	@GetMapping("/customer-service/customers/email/{emailId}")
		public SalesOrder getCustomerDetails(@PathVariable("emailId") String emailId);
}
