package com.salesorder.microservices.orderservice;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;


import ch.qos.logback.classic.Logger;


@RestController
public class OrderController {
	@Autowired
	OrderServiceRepository orderServiceRepository;
	@Autowired
	OrderLineItemRepository orderLineItemRepository;
	@Autowired
	CustomerService customerService;
	@Autowired 
	ItemService itemService;
	private static final org.slf4j.Logger logger = LoggerFactory.getLogger(OrderController.class);

	@PostMapping("/api/service3/orders")
	public Long createOrder(@RequestBody SalesOrderDto salesOrderDto) throws Exception {
		String emailId = salesOrderDto.getEmailId();
	ResponseEntity<SalesOrder> forEntity =new RestTemplate().getForEntity("http://localhost:8000/api/service1/customers/email/{emailId:.+}", 
			SalesOrder.class,emailId);

		//SalesOrder salesOrder = customerService.getCustomerDetails(emailId);	
	SalesOrder salesOrder = forEntity.getBody();
	SalesOrder salesOrderReponse = null;
	if(salesOrder.getEmail() != null) {

	salesOrder.setDate(salesOrderDto.getOrderDate());
	salesOrder.setDescription(salesOrderDto.getOrderDescription());
	salesOrder.setPrice(0);
	 salesOrderReponse =orderServiceRepository.save(salesOrder);

		List<ItemList> itemList;
		itemList = salesOrderDto.getItemList();
		Integer priceAmount = 0;
      for( ItemList itemDetails : itemList) {
    	  String itemName = itemDetails.getItemName();
    	  /*ResponseEntity<OrderLineItem> itemEntity =new RestTemplate().getForEntity("http://localhost:8001/api/service2/items/{itemName}",
    			  OrderLineItem.class,itemName);*/
/*    	  OrderLineItem orderLineItem = itemEntity.getBody();
*/    	  OrderLineItem orderLineItem = itemService.getItemDetails(itemName);
		if(orderLineItem.getName() != null) {
    	  orderLineItem.setQuantity(itemDetails.getQuantity());
    	  priceAmount = priceAmount + (orderLineItem.getPrice() * itemDetails.getQuantity());
    	  orderLineItem.setOrderId(salesOrderReponse.getId());
    	  OrderLineItem orderLineItemEntity =orderLineItemRepository.save(orderLineItem);
    	  salesOrder.setPrice(priceAmount);
		}
		else {

			logger.info("Invalid Name");
			throw new Exception("Item is not available");
		}
      }
      orderServiceRepository.save(salesOrder);
      System.out.println(salesOrder);
	}
	else {
		logger.info("Invalid email");
		throw new Exception("Invalid email Id");
		 
	}
	return salesOrderReponse.getId();
	}


	@GetMapping("/api/service3/orders/{emailId:.+}")
	public SalesOrderDto getOrderDetails(@PathVariable String emailId) {
		SalesOrderDto salesOrderDto = new SalesOrderDto();
		Optional<SalesOrder> salesOrder = orderServiceRepository.findByEmail(emailId);
		salesOrderDto.setSalesOrder(salesOrder);
		List<OrderLineItem> orderLineItemList = new ArrayList<OrderLineItem>();
		orderLineItemList = orderLineItemRepository.findAllByOrderId(salesOrder.get().getId());
		salesOrderDto.setOrderLineItem(orderLineItemList);
		return salesOrderDto;
}

	/*@GetMapping("/api/service3/orders/orderDetails/{orderId}")
	public SalesOrderDto getOrderDetailsByOderId(@PathVariable Long orderId) {
		SalesOrderDto salesOrderDto = new SalesOrderDto();
		Optional<SalesOrder> salesOrder = orderServiceRepository.findOne(orderId);
		salesOrderDto.setSalesOrder(salesOrder);
		List<OrderLineItem> orderLineItemList = new ArrayList<OrderLineItem>();
		orderLineItemList = orderLineItemRepository.findAllByOrderId(salesOrder.get().getId());
		salesOrderDto.setOrderLineItem(orderLineItemList);
		return salesOrderDto;
}
*/
}
