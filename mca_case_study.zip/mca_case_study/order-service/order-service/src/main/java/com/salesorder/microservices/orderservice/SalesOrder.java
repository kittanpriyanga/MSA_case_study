package com.salesorder.microservices.orderservice;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="sales_order")
public class SalesOrder {
@Id
@GeneratedValue(strategy = GenerationType.SEQUENCE)
@Column(name="id")
private Long id;

@Column(name="date")
private String date;

@Column(name="email_id")
private String email;

@Column(name="description")
private String description;

@Column(name="price")
private Integer price;
private int port;

public SalesOrder(Long id, String date, String email, String description, Integer price) {
	super();
	this.id = id;
	this.date = date;
	this.email = email;
	this.description = description;
	this.price = price;
}
public SalesOrder() {}
public Long getId() {
	return id;
}
public void setId(Long id) {
	this.id = id;
}
public String getDate() {
	return date;
}
public void setDate(String date) {
	this.date = date;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
public Integer getPrice() {
	return price;
}
public void setPrice(Integer price) {
	this.price = price;
}
public int getPort() {
	return port;
}
public void setPort(int port) {
	this.port = port;
}



}
